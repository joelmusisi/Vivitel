#!/system/bin/sh

set -eu

BASE_DIR=/sdcard/vivitel/intercom
CONFIG_PATH="$BASE_DIR/config.json"
APK_PATH="$BASE_DIR/app.apk"
PACKAGE_NAME="com.vivitel.camera"
ACTIVITY_NAME="com.vivitel.camera/.MainActivity"
FEEDBACK_SERVICE="com.vivitel.camera/.DeploymentFeedbackService"
FEEDBACK_ACTIVITY="com.vivitel.camera/.DeploymentFeedbackActivity"

start_feedback() {
  am start -n "$FEEDBACK_ACTIVITY" --es action show_progress --es message "Please Wait" >/dev/null 2>&1 || true
  am start-foreground-service \
    -n "$FEEDBACK_SERVICE" \
    --es action start_repeat \
    --es message "Please Wait" \
    --ei intervalSeconds 60 >/dev/null 2>&1 || \
  am startservice \
    -n "$FEEDBACK_SERVICE" \
    --es action start_repeat \
    --es message "Please Wait" \
    --ei intervalSeconds 60 >/dev/null 2>&1 || true
}

complete_feedback() {
  am start -n "$FEEDBACK_ACTIVITY" --es action show_complete --es message "Upload done successfully, please reboot the device" >/dev/null 2>&1 || true
  am start-foreground-service \
    -n "$FEEDBACK_SERVICE" \
    --es action complete \
    --es message "Upload done successfully, please reboot the device" >/dev/null 2>&1 || \
  am startservice \
    -n "$FEEDBACK_SERVICE" \
    --es action complete \
    --es message "Upload done successfully, please reboot the device" >/dev/null 2>&1 || true
}

remove_existing_app() {
  if pm list packages "$PACKAGE_NAME" | grep -q "$PACKAGE_NAME"; then
    am force-stop "$PACKAGE_NAME" 2>/dev/null || true
    pm uninstall "$PACKAGE_NAME" >/dev/null 2>&1 || true
  fi
}

mkdir -p "$BASE_DIR"
if [ -f "$CONFIG_PATH" ]; then
  cp "$CONFIG_PATH" "$BASE_DIR/config.user.backup.$(date +%s)" 2>/dev/null || true
fi
chmod 644 "$CONFIG_PATH" 2>/dev/null || true

start_feedback

if [ -f "$APK_PATH" ]; then
  remove_existing_app
  pm install "$APK_PATH" || pm install -r "$APK_PATH" || true
fi

am force-stop "$PACKAGE_NAME" 2>/dev/null || true
am start -n "$ACTIVITY_NAME" || true
complete_feedback

echo "Vivitel MiTAC deployment script completed."
