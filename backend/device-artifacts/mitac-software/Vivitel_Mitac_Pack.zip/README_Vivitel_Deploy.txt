Vivitel MiTAC Deployment Overlay
================================

This folder now contains only the Vivitel SD-card update overlay and the
scripts needed to rebuild it. It does not ship unused firmware or vendor
software in the deploy output.

What this overlay does
----------------------
1. Provides runtime config that points the camera app to the Vivitel backend.
2. Provides an SD-card startup script that can install app.apk if present and launch the app.
3. Carries the MiTAC positioning target for JT/T808:
   - Host: 204.168.172.4
   - Port: 5015
   - Transport: TCP
4. Ensures the app uses these HTTP API endpoints:
   - https://204.168.172.4:8787/ingest/camera-health
   - https://204.168.172.4:8787/ingest/intercom-audio
   - https://204.168.172.4:8787/intercom/talkback/next
   - https://204.168.172.4:8787/intercom/talkback/{id}/ack

Important limitation
--------------------
This bundle does NOT contain a MiTAC firmware image. Normal Vivitel updates use
the SD-card app/config flow only. Keep firmware flashing separate and use only
vendor-supplied firmware if device recovery is ever required.

Why a device can "black out" after upload (and how this is now prevented)
-------------------------------------------------------------------------
The UNISOC download tool (Setting\FactoryDownload.ini) previously shipped with
Repartition=1 and EraseAll=1. Those settings erase and repartition the ENTIRE
flash, including the bootloader. Because this bundle carries no full firmware
image, a factory/full flash leaves the unit with nothing to boot -> black screen.

Safe-flash defaults are now applied:
- FactoryDownload.ini and UpgradeDownload.ini: Repartition=0, EraseAll=0,
  CheckMatch=1, ComparePartitionInfo=1, Reset=1, PowerOff=0.
- This means the tool only writes the partitions contained in the PAC, verifies
  the image matches the connected chip, and reboots the device after writing.
- Only set Repartition=1 / EraseAll=1 when you intentionally flash a COMPLETE,
  official MiTAC PAC supplied by the vendor.

Recovering a unit that is already blacked out
---------------------------------------------
1. Connect the device over USB and put it in download/boot mode (vendor key combo).
2. Open UpgradeDownload.exe (NOT FactoryDownload) and load the complete official
   MiTAC PAC for this exact model.
3. With CheckMatch=1 the tool confirms the chip before writing; start the download.
4. After it completes the device reboots (Reset=1). Then apply the SD overlay below.

Recommended operator flow
-------------------------
1. Build or refresh the release APK with build_release_apk.ps1.
2. Copy the contents of sdcard\vivitel\intercom\ to the device SD card path /sdcard/vivitel/intercom/.
3. Keep app.apk in that folder so the SD flow installs the current Vivitel build.
4. Set the MiTAC positioning profile to JT/T808 with register server 204.168.172.4:5015 TCP.
5. Keep config.json server.host=204.168.172.4 and server.port=8787 (the Vivitel app
   HTTP API on the VPS), separate from the JT/T808 socket on 5015.
6. Run install.sh on the device, or rely on vendor SD autorun if supported.
7. Confirm camera health reaches the Vivitel backend.
8. Confirm tracking/position separately in Traccar.

Server / TLS note
-----------------
config.json now targets the VPS directly: https://204.168.172.4:8787.
The VPS HTTP API serves HTTPS only when TLS is configured (env TLS_CERT_PATH +
TLS_KEY_PATH, or TLS_CERT + TLS_KEY base64); otherwise it falls back to HTTP.
- If the VPS has a valid TLS cert for 204.168.172.4:8787, keep protocol "https".
- If 8787 is plain HTTP, set config.json server.protocol to "http" so camera
  health, intercom audio, talkback, and remote-settings sync can connect.
These endpoints are consumed by the Video Telematics dashboard and the device
remote-actions page; the device polls /device/pending-settings every 30s and
acks via /device/ack-settings, so configuration changes pushed from the
dashboard (network, time, startup, AI, recording, Vision commands) reach the
unit remotely without re-flashing.

Files included
--------------
- sdcard\vivitel\intercom\config.json
- sdcard\vivitel\intercom\install.sh
- sdcard\vivitel\intercom\app.apk
- sdcard\vivitel\intercom\brand-logo.svg
- sdcard\vivitel\intercom\operator-instructions.txt
- sdcard\vivitel\intercom\SD_CARD_PATH.txt
